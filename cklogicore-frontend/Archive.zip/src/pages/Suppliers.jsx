import { useState } from "react";
import {
  useGetSuppliersQuery,
  useCreateSupplierMutation,
} from "../features/suppliers/supplierApi";
import Modal from "../components/Modal";

export default function Suppliers() {
  const { data = [], isLoading } = useGetSuppliersQuery();
  const [createSupplier] = useCreateSupplierMutation();

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  if (isLoading) return <p>Loading...</p>;

  const submit = async () => {
    await createSupplier({ name, phone });
    setOpen(false);
    setName("");
    setPhone("");
  };

  return (
    <div>
      <h1 className="text-xl mb-4">Suppliers</h1>
      <button onClick={() => setOpen(true)}>Add Supplier</button>

      <table className="w-full mt-4 border">
        <thead>
          <tr>
            <th>Name</th>
            <th>Phone</th>
          </tr>
        </thead>
        <tbody>
          {data.map((s) => (
            <tr key={s.id}>
              <td>{s.name}</td>
              <td>{s.phone}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <Modal open={open} onClose={() => setOpen(false)}>
        <h2>Add Supplier</h2>
        <input value={name} onChange={(e) => setName(e.target.value)} />
        <input value={phone} onChange={(e) => setPhone(e.target.value)} />
        <button onClick={submit}>Save</button>
      </Modal>
    </div>
  );
}
