import { useState } from "react";
import { useCreateTripMutation } from "../features/trips/tripApi";
import { useGetVehiclesQuery } from "../features/vehicles/vehicleApi";
import { useGetSuppliersQuery } from "../features/suppliers/supplierApi";
import { useGetCompaniesQuery } from "../features/companies/companyApi";

export default function Trips() {
  const [createTrip] = useCreateTripMutation();
  const { data: vehicles = [] } = useGetVehiclesQuery();
  const { data: suppliers = [] } = useGetSuppliersQuery();
  const { data: companies = [] } = useGetCompaniesQuery();

  const [form, setForm] = useState({
    vehicleId: "",
    supplierId: "",
    companyId: "",
    income: "",
    expense: "",
  });

  const profit = form.income - form.expense;

  const submit = async () => {
    await createTrip({
      ...form,
      income: Number(form.income),
      expense: Number(form.expense),
    });
  };

  return (
    <div>
      <h1>Create Trip</h1>

      <select onChange={(e) => setForm({ ...form, vehicleId: e.target.value })}>
        <option>Select Vehicle</option>
        {vehicles.map((v) => (
          <option key={v.id} value={v.id}>{v.number}</option>
        ))}
      </select>

      <select onChange={(e) => setForm({ ...form, supplierId: e.target.value })}>
        <option>Select Supplier</option>
        {suppliers.map((s) => (
          <option key={s.id} value={s.id}>{s.name}</option>
        ))}
      </select>

      <select onChange={(e) => setForm({ ...form, companyId: e.target.value })}>
        <option>Select Company</option>
        {companies.map((c) => (
          <option key={c.id} value={c.id}>{c.name}</option>
        ))}
      </select>

      <input placeholder="Income" onChange={(e) => setForm({ ...form, income: e.target.value })} />
      <input placeholder="Expense" onChange={(e) => setForm({ ...form, expense: e.target.value })} />

      <p>Profit: <b>{profit}</b></p>

      <button onClick={submit}>Create Trip</button>
    </div>
  );
}
