import { useState } from "react";
import {
  useGetVehiclesQuery,
  useCreateVehicleMutation,
  useUpdateVehicleMutation,
  useDeleteVehicleMutation,
} from "../features/vehicles/vehicleApi";
import Modal from "../components/Modal";

export default function Vehicles() {
  const { data: vehicles = [], isLoading } = useGetVehiclesQuery();
  const [createVehicle] = useCreateVehicleMutation();
  const [updateVehicle] = useUpdateVehicleMutation();
  const [deleteVehicle] = useDeleteVehicleMutation();

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [number, setNumber] = useState("");
  const [type, setType] = useState("");

  if (isLoading) return <p>Loading...</p>;

  const openAdd = () => {
    setEditing(null);
    setNumber("");
    setType("");
    setOpen(true);
  };

  const openEdit = (vehicle) => {
    setEditing(vehicle);
    setNumber(vehicle.number);
    setType(vehicle.type);
    setOpen(true);
  };

  const submit = async () => {
    const payload = { number, type };

    if (editing) {
      await updateVehicle({ id: editing.id, body: payload });
    } else {
      await createVehicle(payload);
    }
    setOpen(false);
  };

  const remove = async (id) => {
    if (confirm("Delete this vehicle?")) {
      await deleteVehicle(id);
    }
  };

  return (
    <div>
      <h1 className="text-xl mb-4">Vehicles</h1>

      <button onClick={openAdd}>Add Vehicle</button>

      <table className="w-full mt-4 border">
        <thead>
          <tr>
            <th>Number</th>
            <th>Type</th>
            <th width="180">Actions</th>
          </tr>
        </thead>
        <tbody>
          {vehicles.map((v) => (
            <tr key={v.id}>
              <td>{v.number}</td>
              <td>{v.type}</td>
              <td>
                <button onClick={() => openEdit(v)}>Edit</button>
                <button
                  className="ml-2 text-red-500"
                  onClick={() => remove(v.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <Modal open={open} onClose={() => setOpen(false)}>
        <h2 className="mb-2">{editing ? "Edit Vehicle" : "Add Vehicle"}</h2>

        <input
          className="border w-full mb-2"
          placeholder="Vehicle Number"
          value={number}
          onChange={(e) => setNumber(e.target.value)}
        />

        <input
          className="border w-full mb-3"
          placeholder="Vehicle Type"
          value={type}
          onChange={(e) => setType(e.target.value)}
        />

        <button onClick={submit}>
          {editing ? "Update" : "Create"}
        </button>
      </Modal>
    </div>
  );
}
