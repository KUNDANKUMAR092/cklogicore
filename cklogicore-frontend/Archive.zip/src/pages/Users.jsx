function Users() {
  return ( <>
    Users
  </> );
}

export default Users;