import { useState } from "react";
import {
  useGetCompaniesQuery,
  useCreateCompanyMutation,
  useUpdateCompanyMutation,
  useDeleteCompanyMutation,
} from "../features/companies/companyApi";
import Modal from "../components/Modal";

export default function Companies() {
  const { data: companies = [], isLoading } = useGetCompaniesQuery();
  const [createCompany] = useCreateCompanyMutation();
  const [updateCompany] = useUpdateCompanyMutation();
  const [deleteCompany] = useDeleteCompanyMutation();

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [name, setName] = useState("");

  if (isLoading) return <p>Loading...</p>;

  const openAdd = () => {
    setEditing(null);
    setName("");
    setOpen(true);
  };

  const openEdit = (company) => {
    setEditing(company);
    setName(company.name);
    setOpen(true);
  };

  const submit = async () => {
    if (editing) {
      await updateCompany({ id: editing.id, body: { name } });
    } else {
      await createCompany({ name });
    }
    setOpen(false);
  };

  const remove = async (id) => {
    if (confirm("Delete this company?")) {
      await deleteCompany(id);
    }
  };

  return (
    <div>
      <h1 className="text-xl mb-4">Companies</h1>

      <button onClick={openAdd}>Add Company</button>

      <table className="w-full mt-4 border">
        <thead>
          <tr>
            <th>Name</th>
            <th width="180">Actions</th>
          </tr>
        </thead>
        <tbody>
          {companies.map((c) => (
            <tr key={c.id}>
              <td>{c.name}</td>
              <td>
                <button onClick={() => openEdit(c)}>Edit</button>
                <button
                  className="ml-2 text-red-500"
                  onClick={() => remove(c.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <Modal open={open} onClose={() => setOpen(false)}>
        <h2 className="mb-2">{editing ? "Edit Company" : "Add Company"}</h2>

        <input
          className="border w-full mb-3"
          placeholder="Company name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <button onClick={submit}>
          {editing ? "Update" : "Create"}
        </button>
      </Modal>
    </div>
  );
}
