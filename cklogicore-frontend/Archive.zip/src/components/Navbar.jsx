import { Link, useNavigate } from "react-router-dom"
import { useAppSelector } from "../app/hooks"
import { useLogoutMutation } from "../features/auth/authApi"

export default function Navbar() {
  const { user } = useAppSelector((state) => state.auth)
  const [logoutApi] = useLogoutMutation()
  const navigate = useNavigate()

  const handleLogout = async () => {
    try {
      await logoutApi().unwrap()
      navigate("/login", { replace: true })
    } catch (err) {
      console.error("Logout failed", err)
    }
  }

  return (
    <header className="bg-white shadow-md fixed top-0 left-0 right-0 z-50">
      <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
        <Link to="/dashboard" className="text-xl font-bold text-gray-800">
          CKLogicore
        </Link>

        <div className="flex items-center gap-4">
          {user ? (
            <>
              <span className="text-gray-700">
                Hello, <b>{user.name}</b>
              </span>

              <button
                onClick={handleLogout}
                className="bg-black text-white px-3 py-1 rounded hover:bg-gray-800 transition"
              >
                Logout
              </button>
            </>
          ) : (
            <Link
              to="/login"
              className="bg-black text-white px-3 py-1 rounded hover:bg-gray-800 transition"
            >
              Login
            </Link>
          )}
        </div>
      </div>
    </header>
  )
}
