import { Navigate } from "react-router-dom"
import { useAppSelector } from "../app/hooks.js"

export default function ProtectedRoute({ children, roles }) {
  const { user, accessToken } = useAppSelector((state) => state.auth)

  // ❌ User login check
  if (!user || accessToken) return <Navigate to="/login" replace />

  // ✅ Role check
  if (roles && !roles.map(r => r.toLowerCase()).includes(user.role.toLowerCase())) {
    return <Navigate to="/unauthorized" replace />
  }

  // ✅ All good
  return children
}


