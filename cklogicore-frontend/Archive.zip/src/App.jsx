import React, { useEffect } from "react"
import { useAppDispatch } from "./app/hooks.js"
import { setCredentials } from "./features/auth/authSlice.js"
import Navbar from "./components/Navbar.jsx"
import AppRoutes from "./routes/AppRoutes.jsx"

export default function App() {
  const dispatch = useAppDispatch()

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"))
    const accessToken = localStorage.getItem("accessToken")
    if (user && accessToken) {
      dispatch(setCredentials({ user, accessToken }))
    }
  }, [dispatch])
  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <main className="pt-16">
        <AppRoutes />
      </main>
    </div>
  )
}

