import { useDispatch } from "react-redux"
import { useNavigate } from "react-router-dom"
import { logout } from "../features/auth/authSlice"

export default function Topbar() {
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const handleLogout = () => {
    dispatch(logout())
    navigate("/login")
  }

  return (
    <header className="h-14 bg-white border-b flex items-center justify-between px-6">
      <h2 className="font-semibold">Admin Panel</h2>
      <button
        onClick={handleLogout}
        className="text-sm text-red-500"
      >
        Logout
      </button>
    </header>
  )
}
