import { NavLink } from "react-router-dom"
import { useAppSelector } from "../app/hooks"

export default function Sidebar() {
  const { user } = useAppSelector((state) => state.auth)

  const menu = [
    { label: "Dashboard", path: "/dashboard", roles: ["ADMIN","COMPANY","OWNER"] },
    { label: "Suppliers", path: "/suppliers", roles: ["ADMIN","OWNER"] },
    { label: "Companies", path: "/companies", roles: ["ADMIN","OWNER"] },
    { label: "Vehicles", path: "/vehicles", roles: ["ADMIN","OWNER"] },
    { label: "Trips", path: "/trips", roles: ["ADMIN","COMPANY","OWNER"] },
    { label: "Users", path: "/users", roles: ["ADMIN"] },
  ]

  return (
    <aside className="w-64 bg-gray-900 text-white p-5">
      <h1 className="text-xl font-bold mb-8">🚚 Logistics</h1>

      <nav className="space-y-1">
        {menu
          .filter((m) => m.roles.includes(user?.role))
          .map((m) => (
            <NavLink
              key={m.path}
              to={m.path}
              className={({ isActive }) =>
                `block px-4 py-2 rounded ${
                  isActive ? "bg-gray-700" : "hover:bg-gray-800"
                }`
              }
            >
              {m.label}
            </NavLink>
          ))}
      </nav>
    </aside>
  )
}
