import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
  name: "userUI",
  initialState: {
    selectedUser: null,
  },
  reducers: {
    setSelectedUser: (s, a) => { s.selectedUser = a.payload; },
  },
});

export const { setSelectedUser } = userSlice.actions;
export default userSlice.reducer;
