import { Navigate } from "react-router-dom"
import { useAppSelector } from "../app/hooks"

export default function PublicRoute({ children }) {
  const { user, accessToken } = useAppSelector((state) => state.auth)

  if (user && accessToken) {
    return <Navigate to="/dashboard" replace />
  }

  return children
}
