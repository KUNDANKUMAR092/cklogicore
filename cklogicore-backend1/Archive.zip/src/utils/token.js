const jwt = require("jsonwebtoken");

exports.accessToken = payload =>
  jwt.sign(payload, process.env.JWT_ACCESS_SECRET, { expiresIn: "15m" });

exports.refreshToken = payload =>
  jwt.sign(payload, process.env.JWT_REFRESH_SECRET, { expiresIn: "7d" });
