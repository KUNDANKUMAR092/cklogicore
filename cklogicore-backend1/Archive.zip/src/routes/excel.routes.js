const r = require("express").Router();
const c = require("../controllers/excel.controller");
const auth = require("../middlewares/auth.middleware");

r.get("/download", auth, c.download);
module.exports = r;
