export const ROLES = {
  ADMIN: "ADMIN",
  STAFF: "STAFF"
};
