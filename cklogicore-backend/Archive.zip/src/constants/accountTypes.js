// constants/accountTypes.js
export const ACCOUNT_TYPES = {
  SUPPLIER: "SUPPLIER",
  COMPANY: "COMPANY",
  VEHICLE: "VEHICLE"
};
