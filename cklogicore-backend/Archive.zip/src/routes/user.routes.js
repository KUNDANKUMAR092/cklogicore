import express from "express";
import { createUser, getUsers } from "../controllers/user.controller.js";
import { protect } from "../middlewares/auth.middleware.js";
import { allowRoles } from "../middlewares/role.middleware.js";

const router = express.Router();

// ADMIN can create staff
router.post(
  "/",
  protect,
  allowRoles("ADMIN"),
  createUser
);

// ADMIN can see all users
router.get(
  "/",
  protect,
  allowRoles("ADMIN"),
  getUsers
);

export default router;
